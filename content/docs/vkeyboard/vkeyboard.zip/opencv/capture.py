#import pygame
import Image
#from pygame.locals import *
import sys

from cv2.cv import *
# Initialize the camera
capture = CaptureFromCAM(0)  # 0 -> index of camera

if not capture:     # Camera initialized without any errors
    sys.stdout("Error Initalizing Camera!")
    sys.exit(1)

NamedWindow("cam-test",CV_WINDOW_AUTOSIZE)
while True:
    f = QueryFrame(capture)     # capture the frame
    if f:
        ShowImage("cam-test",f)
        WaitKey(10)

DestroyWindow("cam-test")

sys.exit(0)

def get_image():
    im = highgui.cvQueryFrame(camera)
    # Add the line below if you need it (Ubuntu 8.04+)
    #im = opencv.cvGetMat(im)
    #convert Ipl image to PIL image
    return opencv.adaptors.Ipl2PIL(im) 

# fps = 30.0
# pygame.init()
# window = pygame.display.set_mode((640,480))
# pygame.display.set_caption("WebCam Demo")
# screen = pygame.display.get_surface()

# while True:
#     events = pygame.event.get()
#     for event in events:
#         if event.type == QUIT or event.type == KEYDOWN:
#             sys.exit(0)
#     im = get_image()
#     pg_img = pygame.image.frombuffer(im.tostring(), im.size, im.mode)
#     screen.blit(pg_img, (0,0))
#     pygame.display.flip()
#     pygame.time.delay(int(1000 * 1.0/fps))
