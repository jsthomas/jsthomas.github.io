def contour_to_acc_data( contour ):
    cont_array = np.empty( (2,len(contour)), 'float' )
    for ii in range(0,len(contour)):
        xx,yy = contour[ii]
        cont_array[0][ii] = xx
        cont_array[1][ii] = yy

    # Because the positions represent a loop in the plane, we impose
    # "wrap" boundary conditions (i.e. to calculate the convolution at
    # the endpoints, we look at the opposite end of the array).
    kern = 0.5 * np.array( [[-1,0,1]], 'float')
    vel = ndimage.convolve( cont_array, kern, mode='wrap' )
    
    kern = 0.25 * np.array( [[1, 0, -2, 0,1]], 'float')
    acc = ndimage.convolve( cont_array, kern, mode='wrap' )

    acc_sq = acc * acc
    acc_mag = acc_sq[0] + acc_sq[1]
    
    return vel, acc, acc_mag

def contour_to_tips( contour, curv_thresh ):
    vel, acc, acc_mag = contour_to_acc_data( contour )

    tips = []
    for ii in range(0,len(contour)):
        if (vel[0][ii] * acc[1][ii] - vel[1][ii] * acc[0][ii] > 0):
            continue
        if acc_mag[ii] < curv_thresh :
            continue
        if acc_mag[ii] < acc_mag[ii - 1]:
            continue
        if acc_mag[ii] < acc_mag[ (ii+1) % len(acc_mag) ]:
            continue
        tips.append( contour[ii] )

    return tips

def pseudo_gaussian( sigma, size ):
    weights = np.empty( (2*size+1, 2*size+1), dtype='float64' )
    denom = 2 * sigma * sigma
    for ii in range(-size,size+1):
        for jj in range(-size,size+1):
            weights[size+ii,size+jj] = np.exp( (-ii*ii - jj*jj)/denom )

    norm = 1.0 / np.sum(weights)

    return norm * weights
