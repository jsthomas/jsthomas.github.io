import re, math
import vkfrontend as front
import vkutil
from pylab import *

import scipy.ndimage

class TouchTest:

    # A point test object is constructed from a string that specifies
    # the name of the test image and a list of points in row-column
    # coordinates of the correct point positions. 
    #
    # The second argument to the constructor is a pointer to the
    # procedure that will be used to detect the points in question
    # from the input image. The signature of this procedure is: "Image
    # -> Points".
    def __init__(self, string, point_finder, path, comment=""):
        self.input_string = string
        self.path = path
        self.comment = comment;
        self.point_finder = point_finder
        self.parse( string )
        self.calculated_points = None

    def parse( self, string ):
        words = string.split(" ")
        self.filename = words[ 0 ]
        self.img = scipy.ndimage.imread( self.path + self.filename )

        self.correct_points = []
        pattern = re.compile("\(([\s\d]+),([\s\d]+)\)")
        for (str_row, str_col) in pattern.findall( string ):
            self.correct_points.append( (int(str_row), int(str_col) ) )
        self.correct_points = set(self.correct_points)

    @staticmethod
    def argmin( elts, objective ):
        best = None
        for elt in elts:
            if best is None or objective( elt ) < objective( best ):
                best = elt
        return best

    def run( self, dist_cutoff=30 ):
        self.calculated_points = self.point_finder( self.img )
        calc_pts = set( self.calculated_points )
        true_pts = set( self.correct_points ) # copy the set of correct points
        
        true_positives = 0
        false_positives = 0
        false_negatives = 0  
        l2_score = 0       
 
        for qq in true_pts:
            if len(calc_pts) == 0:
                false_negatives += 1
                continue
            
            dist = lambda pp : math.sqrt((pp[0]-qq[0])**2 + (pp[1]-qq[1])**2)
            closest = PointTest.argmin( calc_pts, dist )
            
            if dist(closest) < dist_cutoff:
                true_positives += 1
                l2_score += dist(closest)
                calc_pts.remove( closest )
            else:
                false_negatives += 1
        
        false_positives = len(calc_pts)
        self.l2_score = l2_score
        self.score = (true_positives, false_positives, false_negatives)
        
    def __str__(self):        
        retval = "Test on Image %s\n\t%s\n" % (self.filename, self.comment)
        retval += "\t# Correct Points: %d\n" % len(self.correct_points)
        retval += "\tCorrect Points:" 
        for pt in self.correct_points:
            retval += " (%d,%d)" % pt
        retval += "\n"

        if self.calculated_points is None:
            retval += "\tTest not run.\n"
        else:
            retval += "\tCalculated Points:"
            for pt in self.calculated_points:
                retval += " (%d,%d)" % pt
            retval += "\n"
            retval += "\tScores:\n\t\tL2 Distances: %0.2f\n" % self.l2_score
            retval += "\t\t(TP,FP,FN): %d, %d, %d\n\n" % self.score
        return retval

    def plot(self):
        figure()
        vkutil.show_points( self.correct_points, shapestr='bo' )
        vkutil.show_points_on_image( self.img, self.calculated_points, shapestr='ro' )
        title( self.filename )
