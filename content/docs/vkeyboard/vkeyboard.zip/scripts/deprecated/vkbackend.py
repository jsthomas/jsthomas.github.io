import sys
import scipy.ndimage as ndimage
import numpy as np

class TouchMapper:
    def __init__(self,initial_image):
        self.transf = self.__extract_transformation( initial_image )
        self.kb_SW = (0,0)
        self.kb_SE = (1,0)
        self.kb_NW = (0,1)
        self.kb_NE = (1,1)

    def pts_to_keystrokes( self, points ):
        pts = [ self.kb_coordinates(pt) for pt in points ]
        
        keystrokes = [ "B", "A", "G", "F", "E", "D", "C" ]
    
        retvals = []
        for pt in pts:
            if pt is None: continue
            N = int(np.floor( 9 * pt[1] ) - 1)
            if 0 <= N < 7 :
                retvals.append( keystrokes[ N ] )

        return retvals

    def __extract_transformation( self, ref_img, bthresh=100 ):
        B = ref_img[...,2].astype('float')

        self.kb_mask = (B < 175)
        label_im, labels = ndimage.label( B < bthresh )

        if labels != 4:
            sys.stderr.write("Error: Could not locate four control points. Aborting.\n")
            sys.exit(1)

        pts = []
        com_x = com_y = 0.0 # These record the approximate center of
                            # mass of all of the points.
        for label in range(1,labels+1):
            center = ndimage.center_of_mass( (label_im == label) )
            pts.append( (int(center[0]),int(center[1])) )            
            com_x += center[0]
            com_y += center[1]

        com_x = com_x / 4.0
        com_y = com_y / 4.0

        # Recall that any point here has coordinates (y,x)
        # DOUBLE CHECK HERE!!!
        S = set( pt for pt in pts if pt[1] < com_y )
        if len(S) != 2:
            sys.stderr.write("Error: Could not identify two southward control points. Aborting.\n")
            sys.exit(1)

        W = set( pt for pt in pts if pt[0] < com_x )
        if len(W) != 2:
            sys.stderr.write("Error: Could not identify two westward control points. Aborting.\n")
            sys.exit(1)

        self.SW = self.NW = self.SE = self.NE = None
        for pt in pts:
            if pt in S:
                if pt in W:
                    self.SW = pt
                elif self.SE is None:
                    self.SE = pt
                else:
                    sys.stderr.write("Error: Unidentified control point. Aborting.\n")
                    sys.exit(1)
            else:
                if pt in W:
                    self.NW = pt
                elif self.NE is None:
                    self.NE = pt
                else:
                    sys.stderr.write("Error: Unidentified control point. Aborting.\n")
                    sys.exit(1)

        # We've determined the coordinates of the control points. Now
        # we need to use barycentric coordinates to convert points in
        # image space to points in keyboard space.
        x_1,y_1 = self.SW
        x_2,y_2 = self.SE
        x_3,y_3 = self.NW
        x_4,y_4 = self.NE

        self.det1 = (y_2-y_3)*(x_1-x_3)+(x_3-x_2)*(y_1-y_3)
        self.det2 = (y_2-y_3)*(x_4-x_3)+(x_3-x_2)*(y_4-y_3)

        if self.det1 == 0 or self.det2 == 0:
            sys.stderr.write("Error: Barycentric coordinate transformation is undefined.\n")
            sys.exit(1)

        return 0

    def kb_coordinates( self, img_coords ):
        x,y = img_coords

        x_1,y_1 = self.SW
        x_2,y_2 = self.SE
        x_3,y_3 = self.NW
        x_4,y_4 = self.NE

        mu1 = (1.0 / self.det1) * ((y_2-y_3) * (x - x_3) + (x_3-x_2) * (y - y_3));
        mu2 = (1.0 / self.det1) * ((y_3-y_1) * (x - x_3) + (x_1-x_3) * (y - y_3));
        mu3 = 1.0 - mu1 - mu2;

        tau1 = (1.0 / self.det2) * ((y_2-y_3) * (x - x_3) + (x_3-x_2) * (y - y_3));
        tau2 = (1.0 / self.det2) * ((y_3-y_4) * (x - x_3) + (x_4-x_3) * (y - y_3));
        tau3 = 1.0 - tau1 - tau2;

        p1,q1 = self.kb_SW
        p2,q2 = self.kb_SE
        p3,q3 = self.kb_NW
        p4,q4 = self.kb_NE
        
        if (0 <= mu1 <= 1) and (0 <= mu2 <= 1) and (0 <= mu3 <= 1):
            x_out = mu1 * p1 + mu2 * p2 + mu3 * p3
            y_out = mu1 * q1 + mu2 * q2 + mu3 * q3
            return (x_out, y_out)
        elif (0 <= tau1 <= 1) and (0 <= tau2 <= 1) and (0 <= tau3 <= 1):
            x_out = tau1 * p4 + tau2 * p2 + tau3 * p3
            y_out = tau1 * q4 + tau2 * q2 + tau3 * q3
            return (x_out, y_out)
        else:
            return None
