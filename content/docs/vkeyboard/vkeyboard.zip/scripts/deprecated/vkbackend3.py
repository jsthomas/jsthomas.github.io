import sys
import scipy.ndimage as ndimage
import numpy as np
import math

class TouchMapper:
    
    def __init__(self,initial_image, kb_width, kb_height, pixel_width, epsilon=5):
        self.epsilon = float(epsilon)
        self.kb_width = float(kb_width)
        self.kb_height = float(kb_height)
        self.pix_width = float(pixel_width)
        self.im_height, self.im_width, d = initial_image.shape

        self.transf = self.__extract_transformation( initial_image )

    def pts_to_keystrokes( self, points ):
        pts = [ self.kb_coordinates(pt) for pt in points ]
        
        keystrokes = [ "B", "A", "G", "F", "E", "D", "C" ]
    
        retvals = []
        for pt in pts:
            if pt is None: continue
            N = int(np.floor( 9 * pt[1] ) - 1)
            if 0 <= N < 7 :
                retvals.append( keystrokes[ N ] )

        return retvals
    
    def __extract_transformation( self, ref_img, bthresh=100 ):
        B = ref_img[...,2].astype('float')

        self.kb_mask = (B < 175)
        label_im, labels = ndimage.label( B < bthresh )

        if labels != 4:
            sys.stderr.write("Error: Could not locate four control points. Aborting.\n")
            sys.exit(1)

        pts = []
        com_row = com_col = 0.0 # These record the approximate center of
                            # mass of all of the points.
        for label in range(1,labels+1):
            center = ndimage.center_of_mass( (label_im == label) )
            pts.append( (int(center[0]),int(center[1])) )            
            com_row += center[0]
            com_col += center[1]

        com_row = com_row / 4.0
        com_col = com_col / 4.0

        # Recall that any point here has coordinates
        # (y,x)=(row,column)
        S = set( pt for pt in pts if pt[0] > com_row )
        if len(S) != 2:
            sys.stderr.write("Error: Could not identify two southward control points. Aborting.\n")
            sys.exit(1)

        W = set( pt for pt in pts if pt[1] < com_col )
        if len(W) != 2:
            sys.stderr.write("Error: Could not identify two westward control points. Aborting.\n")
            sys.exit(1)

        self.SW = self.NW = self.SE = self.NE = None
        for pt in pts:
            if pt in S:
                if pt in W:
                    self.SW = pt
                elif self.SE is None:
                    self.SE = pt
                else:
                    sys.stderr.write("Error: Unidentified control point. Aborting.\n")
                    sys.exit(1)
            else:
                if pt in W:
                    self.NW = pt
                elif self.NE is None:
                    self.NE = pt
                else:
                    sys.stderr.write("Error: Unidentified control point. Aborting.\n")
                    sys.exit(1)

        # Making these assignments of variables puts us in our usual
        # perspective coordinates (from xyz Euclidean coordinates).
        
        v_0,u_0 = self.SW
        v_1,u_1 = self.SE
        v_2,u_2 = self.NE
        v_3,u_3 = self.NW
        
        pw = self.pix_width
        self.q_front = self.kb_width / ( pw * (u_1 - u_0) )
        self.q_back  = self.kb_width / ( pw * (u_2 - u_3) )
        
        if abs(v_1 - v_0) > self.epsilon or abs( v_2 - v_3 ) > self.epsilon:
            sys.stderr.write("Warning: Optical axis is not properly aligned with the viewing plane.\n");
            sys.stderr.write("Error Amounts: |v_1 - v_0| = %d, |v_2 - v_3| = %d.\n" \
                                 % (abs(v_1-v_0),abs(v_2-v_3)))

        return 0

    def make_euclidean_coords( self, rowcol ):
        row,col = rowcol
        return (col, self.im_height - row)

    def kb_coordinates( self, img_coords ):
        tan_alpha = 165.0 / 323.0
        sin_alpha = 165.0 / 362.0
        cos_alpha = 323.0 / 362.0

        # Comment: The 3.67 / 0.005575 parameters appear to work better.
        f =  4.93 # 3.67    # 
        s = 0.0075 # 0.005575 # 
        u,v = (img_coords[1], self.im_height - img_coords[0])
        
        u = u * s
        v = v * s

        x = (u + (f/s) * tan_alpha ) / ( 1 - (s/f) * u * tan_alpha )
        y = v * ( (s/f) * x * sin_alpha + cos_alpha ) 
        
        return (x,y)
