def find_hand_ctr( img ):
    bw = locate_hand( img )
    erode = ndi.binary_erosion( bw, np.ones((3,3)) )
    return np.logical_xor( bw, erode )

def tophat( rgb_img, size ):
    out = np.zeros_like(rgb_img)
    for ii in range(0,3):
        out[...,ii] = ndi.morphology.white_tophat(rgb_img[...,ii],size=(size,size))
    return out

def thin( img, strel ):
    sub = ndi.morphology.binary_hit_or_miss( img, structure1=strel )
    sub = np.logical_not( sub )
    return np.logical_and( img, sub )
